"""Initialization module for api"""
