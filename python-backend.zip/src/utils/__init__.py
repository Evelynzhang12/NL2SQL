"""Initialization module for utils"""
