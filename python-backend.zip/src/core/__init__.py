"""Initialization module for core"""
